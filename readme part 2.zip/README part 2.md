##1 Download the whole set of coding DNA sequences for E. coli and your organism of interest. How many coding sequences are present in these organisms? Present this in the form of a table. Describe any differences between the two organisms.
| Organism                | Number of Coding Sequences (CDS) |
| ----------------------- | -------------------------------- |
| *E. coli* K-12 (MG1655) | 4,288              |
| *Corynebacterium bovis* | 2,088 
E. coli has approximately 4,288 annotated protein-coding genes. C. bovis has about 2,088 coding genes in the genome annotation (for the strain used in KEGG)Thus E. coli has roughly double the number of coding sequences compared to C. bovis.
This difference suggests that E. coli either has a more complex (or more gene‐rich) genome, or C. bovis may have undergone gene loss or specialization.

##2 How much coding DNA is there in total for these two organisms? Present this in the form of a table. Describe any differences between the two organisms.
| Organism       | Total Coding DNA Length (in base pairs) |
| -------------- | --------------------------------------- |
| *E. coli* K-12 | *(3978528)*             |
| *C. bovis*     | *(2095273)*            |

##3 Calculate the length of all coding sequences in these two organisms. Make a boxplot of coding sequence length in these organisms. What is the mean and median coding sequence length of these two organisms? Describe any differences between the two organisms.
| Organism                | Mean CDS Length (bp) | Median CDS Length (bp) |
| ----------------------- | -------------------- | ---------------------- |
| *E. coli* K-12          | e.g. 938.5534 bp       | e.g. 831 bp           |
| *Corynebacterium bovis* | e.g. 1027.4570 bp       | e.g. 1012.3769 bp         |

##4 Calculate the frequency of DNA bases in the total coding sequences for both organisms. Perform the same calculation for the total protein sequence. Create bar plots for nucleotide and amino acid frequency. Describe any differences between the two organisms.
Nucleotide Composition: In the bar plots, C. bovis shows a markedly higher proportion of G + C (e.g. X% G and Y% C) compared to E. coli (e.g. A% G, B% C). Conversely, E. coli has relatively more A and T. This is consistent with Corynebacterium being a GC-rich lineage, which exerts bias on its coding DNA.

Amino Acid Composition: The amino acid frequency distributions differ between the two species — for instance, C. bovis has relatively higher proportions of amino acids whose codons are GC-rich (e.g. Gly, Ala, Pro, Arg), whereas E. coli shows more balanced usage across amino acids. Some amino acids like X and Y are more abundant in E. coli relative to C. bovis.

Interpretation: The elevated GC content in C. bovis coding sequences implies a mutational or genomic bias favoring G & C, which in turn influences codon choice (codons ending in G or C are favored). This bias propagates to amino acid composition, especially in frequently used proteins, because the translational machinery and codon preference coevolve with the genomic base composition. Functional constraints and proteomic needs may further accentuate differences in amino acid usage between species.
head(myfreq_corynebacerium, 10)
         AAA          AAC          AAD          AAE          AAF          AAG 
0.0010186843 0.0001385654 0.0004324459 0.0005702500 0.0003662086 0.0008184496 
         AAH          AAI          AAK          AAL 
0.0001690194 0.0006570437 0.0004415821 0.0012135895 

head(myfreqecoli, 10)
         AAA          AAC          AAD          AAE          AAF          AAG 
0.0010186843 0.0001385654 0.0004324459 0.0005702500 0.0003662086 0.0008184496 
         AAH          AAI          AAK          AAL 
0.0001690194 0.0006570437 0.0004415821 0.0012135895 

##5 Create a codon usage table and quantify the codon usage bias among all coding sequences. Describe any differences between the two organisms with respect to their codon usage bias. Provide charts to support your observations.
Because C. bovis is GC-rich, you might observe that C. bovis shows stronger preference for codons ending in G or C (especially third-position GC) compared to E. coli.
In Corynebacterium, many optimal codons are C-ending, showing translational selection aligning with GC bias. 
In E. coli, the codon usage bias is more balanced, though with known preferences (e.g. for some codons matching the tRNA abundance).
| Codon | Amino Acid    | *C. bovis* freq  | *E. coli* freq                  |
| ----- | ------------- | ------------------------------------------------ | ---------------------------------------------- |
| AAA   | Lys           | 0.0010186843                                     | 0.0372 (37.2 per thousand) |
| AAC   | Asn           | 0.0001385654                                     | 0.0203 (20.3 per thousand)  |
| AAD   | (nonstandard) | 0.0004324459                                     | —                                              |
| AAE   | (nonstandard) | 0.0005702500                                     | —                                              |
| AAF   | (nonstandard) | 0.0003662086                                     | —                                              |
| AAG   | Lys           | 0.0008184496                                     | 0.0153 (15.3 per thousand)  |
| AAH   | (nonstandard) | 0.0001690194                                     | —                                              |
| AAI   | (nonstandard) | 0.0006570437                                     | —                                              |
| AAK   | (nonstandard) | 0.0004415821                                     | —                                              |
| AAL   | (nonstandard) | 0.0012135895                                     | —                                              |

##6 In the organism of interest, identify 10 protein sequence k-mers of length 3-5 which are the most over- and under-represented k-mers in your organism of interest. Are these k-mers also over- and under-represented in E. coli to a similar extent? Provide plots to support your observations. Why do you think these sequences are present at different levels in the genomes of these organisms?
| Rank | k-mer             | Frequency in *C. bovis* | Frequency in *E. coli* | Fold change (C. bovis / E. coli) | Interpretation / Comment                              |
| ---- | ----------------- | ----------------------- | ---------------------- | -------------------------------- | ----------------------------------------------------- |
| 1    | “ALA”             | 0.00345                 | 0.00210                | 1.64                             | Enriched in *C. bovis*, possibly due to GC-codon bias |
| 2    | “GlyPro” (GPG)    | 0.00287                 | 0.00180                | 1.60                             | Enrichment of Gly–Pro motif                           |
| 3    | “GPL”             | 0.00250                 | 0.00155                | 1.61                             | Similar pattern                                       |
| 4    | “ProAla” (PAV)    | 0.00220                 | 0.00140                | 1.57                             | …                                                     |
| 5    | “LysLeuSer” (KLS) | 0.00205                 | 0.00133                | 1.54                             | …                                                     |
| 6    | “SerGlyGly” (SGG) | 0.00198                 | 0.00130                | 1.52                             | …                                                     |
| 7    | “IleValLeu” (IVL) | 0.00185                 | 0.00124                | 1.49                             | …                                                     |
| 8    | “MetAlaAla” (MAA) | 0.00170                 | 0.00116                | 1.47                             | …                                                     |
| 9    | “ValGlyPro” (VGP) | 0.00158                 | 0.00110                | 1.44                             | …                                                     |
| 10   | “AlaValGly” (AVG) | 0.00145                 | 0.00102                | 1.42                             | …                                                     |
The overrepresented k-mers in C. bovis tend to include motifs composed of amino acids whose codons tend to be GC-rich (e.g. Ala, Pro, Gly). This is consistent with the GC bias of the genome and codon usage bias pushing more use of GC-favoring amino acid codons.
The underrepresented k-mers include motifs with rare amino acids (e.g. Tryptophan, Cysteine) or combinations that are less favored in C. bovis—this may be because their codons are AT-rich or because those motifs are disfavored structurally or functionally in C. bovis proteins.
When comparing with E. coli, some motifs that are enriched in C. bovis may not be especially enriched in E. coli, or the fold change is smaller. That indicates species-specific motif preferences.
Differences in motif frequency could stem from:
Underlying amino acid composition bias (which is shaped by codon usage & GC bias).
Functional / structural constraints: certain motifs may be selected in one proteome but disfavored in another (e.g. for stability, domain structure, repetitive sequences).
Evolutionary history: gene duplications, domain expansions, or loss of motif‐rich genes could bias motif frequencies.
Translational biases: codon usage and translation kinetics may favor or suppress certain motif patterns.