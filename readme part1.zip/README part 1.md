###1 Read in the file, making the gene identifiers the row names. Show a table of values for the first six genes.
Data Import:
The file gene_expression.tsv is downloaded from the GitHub repository.
The data is read into R using read.delim(), with gene identifiers assigned as row names.

Inspecting Data:
The first six rows of the dataset are displayed using head(cds) to confirm successful import and understand the structure of the data.

###2 Make a new column which is the mean of the other columns. Show a table of values for the first six genes.
A new column named mean_column is added, which stores the average expression level across all samples for each gene.

###3 List the 10 genes with the highest mean expression.
The dataset is sorted in descending order based on the mean expression values.
The top 10 genes with the highest mean expression are identified from the sorted data.The updated table with the new mean column is displayed for the first six genes

###4 Determine the number of genes with a mean <10.
Genes with a mean expression level less than 10 are extracted and counted to determine how many genes show low expression across samples.

##5 Make a histogram plot of the mean values and include it into your report. write readme answer for this question.
A histogram plot is generated using hist() to display the distribution of mean gene expression values across all genes.The x-axis represents the mean expression, while the y-axis shows the frequency of genes within each range.

##6 Import this csv file into an R object. What are the column names?
The file growth_data.csv is downloaded or read from its URL and loaded into R using read.csv(). The colnames() function is used to display the column names of the dataframe, revealing how the data are structured (e.g. site identifier, circumference in 2005, circumference in 2020, perhaps additional metadata columns).

##7 Calculate the mean and standard deviation of tree circumference at the start and end of the study at both sites.
The data are subset into two site-specific groups: Northeast and Southwest, based on the Site column (e.g. via subset() or using grep()).
For each site, the mean and standard deviation (sd) of tree circumference are calculated separately for the year 2005 and 2020.
Example: mean(Northeast$Circumf_2005_cm) and sd(Northeast$Circumf_2005_cm), and similarly for Circumf_2020_cm and for the Southwest group.

##8 Make a box plot of tree circumference at the start and end of the study at both sites.
Two box plots are drawn:
One box plot for the Northeast site, comparing circumference in 2005 vs 2020.
Another box plot for the Southwest site, comparing circumference in 2005 vs 2020.
Each box plot shows the distribution of tree circumferences at those two time points in each site, allowing for visual comparison of central tendency and spread.

##9 Calculate the mean growth over the last 10 years at each site.
For each individual tree, the growth is calculated as Circumf_2020_cm – Circumf_2005_cm.The average (mean) of those growth differences is computed for each site:
mean(Northeast_difference) gives the mean 10-year growth at Northeast.
mean(Southwest_difference) gives the mean 10-year growth at Southwest.

##10 Use the t.test to estimate the p-value that the 10 year growth is different at the two sites.
A two-sample t-test is used to compare the distributions of 10-year growth between the Northeast and Southwest sites.
The t.test() function is applied to the two vectors of growth differences.
The p-value from the t-test is extracted (e.g. t_test_result$p.value), which tests the null hypothesis that the mean growth is the same in both sites.